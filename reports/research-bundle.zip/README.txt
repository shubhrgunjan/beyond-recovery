Open research-report.html to read the report offline. Figures, videos and compact data tables are included.

Public research home: https://beyond-recovery.vercel.app
Online report: https://beyond-recovery.vercel.app/report/
Shared live simulator: https://beyond-recovery.vercel.app/lab
Raw data and checksums: https://beyond-recovery.vercel.app/downloads/
Source: https://github.com/shubhrgunjan/beyond-recovery

This publication copy updates navigation links; underlying experimental measurements are unchanged. The full raw archives are downloaded separately.
